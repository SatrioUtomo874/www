PAKET CONTOH MODE BATCH GEOTAG STUDIO
======================================

ISI PAKET
- Template_Koordinat_Batch.xlsx : template koordinat untuk folder bernomor.
- Contoh_Pengisian_Koordinat.xlsx : contoh pengisian dua pasangan koordinat.
- Folder_Input_Contoh : contoh folder foto untuk Mode Batch.

CONTOH FOLDER
Folder_Input_Contoh/
  Album_Foto_Bebas/
    1/
      Logo_HTML_Folder_1.jpg
    2/
      Logo_HTML_Folder_2.jpg

Logo HTML digunakan sebagai foto contoh. File contoh ini hanya untuk mencoba
alur pemrosesan, bukan foto dokumentasi lokasi sebenarnya.

CARA MENGGUNAKAN
1. Buka GeoTag Studio, lalu pilih Mode Batch.
2. Pilih Template_Koordinat_Batch.xlsx atau Contoh_Pengisian_Koordinat.xlsx.
3. Pilih folder Album_Foto_Bebas sebagai folder utama foto.
4. Periksa pratinjau pencocokan folder dan koordinat.
5. Lanjutkan proses setelah koordinat dipastikan benar.

PENTING
- Folder 1 menggunakan koordinat di B2 dan C2.
- Folder 2 menggunakan koordinat di B3 dan C3.
- Nama folder utama dan nama file foto boleh bebas.
- Subfolder langsung harus menggunakan nomor, misalnya 1, 2, 3.
- Gunakan titik (.) sebagai pemisah desimal koordinat.
- Foto contoh berupa JPG agar sesuai dengan format yang didukung aplikasi.

© 2026 Satrio Utomo. All rights reserved.
